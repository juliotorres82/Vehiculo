/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import smartphone.smartphone1;

 Import fes.aragon.ico.poo.SourcePackages.smartphone;

/**
 *
 * @author BETTY
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        smartphone1 smart1= new smartphone1();
        smartphone1 smart2;
        smart2 = new smartphone1("Alto, 1.5 , pequeño");
        
    }
    
}
